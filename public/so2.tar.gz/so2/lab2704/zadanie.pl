#!/usr/bin/perl -w

#dla kazdego bezposredniego katalogu zadanego katalogu
#wypisac czy znajduje sie w nim wiecej dowiazan symbolicznych 
#popawnych czy zdefiniowanych sciezka wzgledna


my $dir = $ARGV[0];

if (not defined $dir) {
	die "No argument provided\n";
}

if (! -d $dir) {
	die "Argument is not a directory\n";
}

opendir (OUTER, $dir) || die "Error opening dir\n";
@files = readdir(OUTER);
foreach $dirname (@files) {
	$dirname = $dir."/".$dirname;
	if (! -d $dirname) {
		next;
	} else {
		opendir(INNER,$dirname);
		$correct = 0;
		$relative = 0;
		print "You are in directory " . $dirname ."\n";
		while (($filename = readdir(INNER))) {
			$filename = $dirname."/".$filename;
			if ( -l $filename) {
				$link = readlink $filename;
				if (index($link, "/") != 0) {
					$relative+=1;		
				}
				if ( -e $link) {
					$correct+=1;
				}	
			} else {
				next;
			}
		}
		$test = $correct > $relative ? "correct" : ($correct<$relative ? "relative" : "equal");
		if($test ne "equal") {
			print "There are more ". $test . " links\n";
		} else {
			print "Equal number of links with both types\n";
		}
		closedir(INNER);
	}
}
closedir(OUTER);

