#!/usr/bin/perl -w

#w zadanym drzewie katalogowym znalezc (wypisac) niepuste katalogi oraz pliki regularne, do ktorych my (wykonawca skryptu)
# mamy prawo zapisu. Wyniki posortowac

use File::Find;

my $dir = $ARGV[0];

if (not defined $dir) {
	die "No argument provided\n";
}

if (! -d $dir) {
	die "Argument is not a directory\n";
}

#opendir (DIR, $dir) || die "Error opening dir\n";
#@files = readdir(DIR);
#closedir(DIR);

@results = ();
find(\&do_something, $dir);
@sorted = sort @results;

print @sorted;

sub do_something
{
	if (((-d $_ && !is_folder_empty($_)) || (-f $_)) && -w $_) {
	$res = $_ . "\n";
	push @results, $res;
	}
}

sub is_folder_empty {
    $dirname = shift;
    opendir($dh, $dirname) or die "Not a directory";
    return scalar(grep { $_ ne "." && $_ ne ".." } readdir($dh)) == 0;
    closedir($dh);
}


