#!/usr/bin/perl -w

#Dane jest N drzew katalogowych. 
#Znalezc pliki, do ktorych grupa ma prawo odczytu, 
#a nie ma prawa zapisu i wykonania. 
#Policzyc liczbe plikow znalezionych w kazdym z tych drzew katalogowych.

use File::Find;
use Fcntl ':mode';

#my $dir = $ARGV[0];

#if (not defined $dir) {
#	die "No argument provided\n";
#}

#if (! -d $dir) {
#	die "Argument is not a directory\n";
#}

foreach $dir (@ARGV) {
	if (! -d $dir) {
		print "Argument " . $dir . " is not a directory!";
		next;
	} 
	$res = 0;
	find(\&do_something, $dir);
	print "Dir: " . $dir . " found: " . $res . "\n";
}

sub do_something
{
	$mode = (stat ($_))[2];
	$gr = ($mode & S_IRGRP);
	$gw = ($mode & S_IWGRP);
	$gx = ($mode & S_IXGRP);
	if ($gr!=0 && $gw==0 && $gx==0) { 
		$res+=1;
	}
}
