#!/usr/bin/perl

#dane sa drzewa katalogowe a i b
#stwierdzic czy zadane drzewa sa rozlaczne, identyczne, czy jedno jest
#poddrzewem drugiego (ktore ktorego)

use Cwd 'abs_path';

$dir1 = $ARGV[0];
$dir2 = $ARGV[1];

if (not defined $dir1 || not defined $dir2) {
        die "No argument provided\n";
}

if (! -d $dir1 && ! -d $dir2) {
        die "Argument is not a directory\n";
}
$dirpath1 = abs_path($dir1) . "/";
$dirpath2 = abs_path($dir2) . "/";

if ($dirpath1 eq $dirpath2) {
print "directories are identical \n";
} elsif (index($dirpath1,$dirpath2) == 0) {
print "dir 1 is in dir 2 \n";
} elsif (index($dirpath2, $dirpath1) == 0) {
print "dir 2 is in dir 1 \n";
} else {
"directories are complement \n";
}


